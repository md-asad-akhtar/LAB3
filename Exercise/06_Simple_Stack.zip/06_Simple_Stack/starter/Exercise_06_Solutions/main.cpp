#include <iostream>
#include "Stack.h"

//One possible solution, shall be kept
bool isPrime(int number){
    if(number < 2) return false;
    for(int i = 2;i<number;i++){
        if(number%i == 0) return false;
    }
    return true;
}

// function shall be gone for students
Stack primeStack(int upper_bound){
    Stack r_Stack;
    for(int i = upper_bound; i>1;i--){
        if(isPrime(i)) r_Stack.push(i);
    }
    return r_Stack;
}

//main should be empty
int main() {
    Stack my_Stack = primeStack(1000);
    my_Stack.print();
    return 0;
}
