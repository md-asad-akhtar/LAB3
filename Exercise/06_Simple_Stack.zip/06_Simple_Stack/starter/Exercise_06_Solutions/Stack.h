//
// Created by Thies Josten on 12.11.24.
//

#ifndef EXERCISE_06_STACK_H
#define EXERCISE_06_STACK_H


class Stack {

//fields and Element are given
private:
    struct Element{
        int value;
        Element* next;
    };
    Element* head{nullptr};
    int length{0};

public:
    Stack() = default;
    void push(int value);
    void pop();
    
    // method declarations underneath shall be removed
    ~Stack();
    int size();
    void print();
};


#endif //EXERCISE_06_STACK_H
