//
// Created by Thies Josten on 12.11.24.
//

#include <stdexcept>
#include <iostream>
#include "Stack.h"

//file should be empty from here onwards

void Stack::push(int value) {
    Element* temp = head;
    head = new Element{value};
    head->next = temp;
    length++;
}

int Stack::size() {
    return length;
}

void Stack::pop() {
    if(head == nullptr) throw std::length_error{"Can not pop an element from an empty stack."};

    Element* popped_element = head;
    head = head->next;

    delete popped_element;
    popped_element = nullptr;
    length--;

}

void Stack::print() {
    if(head != nullptr){
        std::cout << "[" << head->value;
    } else{
        std::cout << "[]" << std::endl;
        return;
    }
    Element* temp = head->next;
    while (temp != nullptr){
        std::cout << ", " << temp->value;
        temp = temp->next;
    }
    std::cout << "]" << std::endl;
}

Stack::~Stack(){
    Element* e = head;
    while (e != nullptr){
        Element* next = e->next;
        delete e;
        e = next;
    }
    std::cout << "My first own Destructor :)" << std::endl;
}